<p align="center"><a href="https://dirnis.az" target="_blank"><img src="./public/frontend/images/logos/logo.png" width="400" alt="DXC"></a></p>


## Dırnıs Xeyriyyə Cəmiyyətinin rəsmi web saytı
